## segway 3.0.3 run d450cd90bf2511eb9e98b9e745a90971 at 2021-05-27 19:57:56.201238

cd "/cromwell-executions/test_segway_train/d2240420-6de8-41da-b5c1-6721cadbaded/call-segway_train/execution"
"/opt/conda/bin/segway" "train" "--num-labels" "10" "--resolution" "100" "--minibatch-fraction" "0.1" "--num-instances" "2" "--segtransition-weight-scale" "1.0" "--max-train-rounds" "5" "/cromwell-executions/test_segway_train/d2240420-6de8-41da-b5c1-6721cadbaded/call-segway_train/inputs/555679176/files.genomedata" "traindir"
