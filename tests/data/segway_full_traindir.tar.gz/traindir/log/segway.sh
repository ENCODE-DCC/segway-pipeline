## segway 3.0 run 6ba0c02cfede11eb8af45789265d139b at 2021-08-16 22:08:00.704378

cd "/cromwell-executions/segway/2215b223-4ec5-45be-934d-50e1edd114f8/call-segway_train/execution"
"/opt/conda/bin/segway" "train" "--num-labels" "10" "--resolution" "100" "--minibatch-fraction" "0.1" "--num-instances" "2" "--segtransition-weight-scale" "6.0" "--max-train-rounds" "5" "/cromwell-executions/segway/2215b223-4ec5-45be-934d-50e1edd114f8/call-segway_train/inputs/-1623904976/files.genomedata" "traindir"
