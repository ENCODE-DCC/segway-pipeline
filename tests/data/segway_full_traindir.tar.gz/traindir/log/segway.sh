## segway 3.0.3 run cdf5e91e1a3111ec89940df09be66d2f at 2021-09-20 16:42:55.336452

cd "/cromwell-executions/segway/3144b73d-1194-4f63-a959-f5a657ecde0e/call-segway_train/execution"
"/opt/conda/bin/segway" "train" "--num-labels" "10" "--resolution" "100" "--minibatch-fraction" "0.1" "--num-instances" "2" "--prior-strength" "1.0" "--segtransition-weight-scale" "2.0" "--ruler-scale" "100" "--track-weight" "0.0" "--max-train-rounds" "5" "/cromwell-executions/segway/3144b73d-1194-4f63-a959-f5a657ecde0e/call-segway_train/inputs/-2075751689/files.genomedata" "traindir"
