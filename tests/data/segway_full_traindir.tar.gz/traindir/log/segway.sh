## segway 3.0.3 run e495a52247ce11ec823d87937ba4287d at 2021-11-17 17:50:46.594853

cd "/cromwell-executions/segway/17ba3b16-186e-48f9-9f54-6b5882d5fb10/call-segway_train/execution"
"/opt/conda/bin/segway" "train" "--num-labels" "10" "--resolution" "100" "--minibatch-fraction" "0.1" "--num-instances" "2" "--prior-strength" "1.0" "--segtransition-weight-scale" "2.0" "--ruler-scale" "100" "--track-weight" "0.01" "--max-train-rounds" "5" "/cromwell-executions/segway/17ba3b16-186e-48f9-9f54-6b5882d5fb10/call-segway_train/inputs/-782265582/files.genomedata" "traindir"
