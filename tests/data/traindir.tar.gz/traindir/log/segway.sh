## segway 3.0 run 02b6df2a8fda11eabac613d890aac673 at 2020-05-06 20:41:49.953367

cd "/cromwell-executions/test_segway_train/bc652201-1b4f-4960-9e3b-8f23c42b1bbc/call-segway_train/execution"
"/opt/conda/bin/segway" "train" "--num-labels" "10" "--resolution" "100" "--minibatch-fraction" "0.1" "--num-instances" "2" "--segtransition-weight-scale" "1.0" "--max-train-rounds" "5" "/cromwell-executions/test_segway_train/bc652201-1b4f-4960-9e3b-8f23c42b1bbc/call-segway_train/inputs/-1798891369/files.genomedata" "traindir"
