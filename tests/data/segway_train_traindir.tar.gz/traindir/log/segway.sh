## segway 3.0.3 run d026a0541a3911ecad13a99f6672ce90 at 2021-09-20 17:40:14.961502

cd "/cromwell-executions/test_segway_train/4baaf1ce-3fa1-45f5-bada-02180a1549c0/call-segway_train/execution"
"/opt/conda/bin/segway" "train" "--num-labels" "10" "--resolution" "100" "--minibatch-fraction" "0.1" "--num-instances" "2" "--prior-strength" "1.0" "--segtransition-weight-scale" "1.0" "--ruler-scale" "100" "--track-weight" "0.01" "--max-train-rounds" "5" "/cromwell-executions/test_segway_train/4baaf1ce-3fa1-45f5-bada-02180a1549c0/call-segway_train/inputs/929268548/files.genomedata" "traindir"
