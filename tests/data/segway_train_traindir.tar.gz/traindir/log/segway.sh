## segway 3.0 run 49eb03ceff9811ebbb13a75c7a01bb91 at 2021-08-17 20:18:30.536971

cd "/cromwell-executions/test_segway_train/25bdfb38-26dc-43f6-8f4b-4ff55b5e6ad1/call-segway_train/execution"
"/opt/conda/bin/segway" "train" "--num-labels" "10" "--resolution" "100" "--minibatch-fraction" "0.1" "--num-instances" "2" "--segtransition-weight-scale" "1.0" "--max-train-rounds" "5" "/cromwell-executions/test_segway_train/25bdfb38-26dc-43f6-8f4b-4ff55b5e6ad1/call-segway_train/inputs/1150288547/files.genomedata" "traindir"
